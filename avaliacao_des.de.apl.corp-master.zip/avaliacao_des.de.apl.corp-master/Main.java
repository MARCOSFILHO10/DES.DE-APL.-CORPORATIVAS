
public class Main {

	public static void main(String[] args) {
		Cliente infoPessoalXml = new InfoPessoal();
		Cliente infoEmpresaXml = new InfoEmpresa(infoPessoalXml);

	}

}
