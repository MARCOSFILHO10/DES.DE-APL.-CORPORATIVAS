# avaliacao_des.de.apl.corp

Primeira Parte Avaliação II - Change of Responsability
